package com.mysiteforme.admin.dao;

import com.mysiteforme.admin.entity.Site;
import com.baomidou.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author wangl
 * @since 2017-12-30
 */
public interface SiteDao extends BaseMapper<Site> {

}